<?php
@session_start();
@ob_start();

// if (!isset($_SESSION['admin_id'])) {
//     header('Location: login.php');
//     exit();
// }

@define("DATA", "data/");
@define("SAYFA", "include/");

include_once(DATA . "baglanti.php");

$query = "SELECT * FROM site_ayar";
$stmt = $baglanti->prepare($query);
$stmt->execute();

$ayarlar = $stmt->fetch(PDO::FETCH_ASSOC);

if ($ayarlar) {
    $ayar_ad = $ayarlar["ayar_ad"];
    $ayar_url = $ayarlar["ayar_url"];
    define("SITE", $ayar_url);
}

?>

<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title><?= $ayar_ad ?> Admin Panel</title>
    <link rel="icon" type="image/png" sizes="96x96" href="./img/fav.png">

    <link
        href="./assets/libs/fullcalendar/dist/fullcalendar.min.css"
        rel="stylesheet" />

    <link
        rel="stylesheet"
        type="text/css"
        href="./assets/extra-libs/multicheck/multicheck.css" />
    <link
        href="./assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.css"
        rel="stylesheet" />

    <link href="./assets/extra-libs/calendar/calendar.css" rel="stylesheet" />
    <link href="./dist/css/style.min.css" rel="stylesheet" />
    <link
        rel="stylesheet"
        type="text/css"
        href="./assets/libs/select2/dist/css/select2.min.css" />
    <link
        rel="stylesheet"
        type="text/css"
        href="./assets/libs/jquery-minicolors/jquery.minicolors.css" />
    <link
        rel="stylesheet"
        type="text/css"
        href="./assets/libs/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css" />
    <link href="./dist/css/style.min.css" rel="stylesheet" />

    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@5.10.0/main.css" rel="stylesheet">
    <style>
        .scrollable-table {
            max-height: 210px; 
            overflow-y: auto;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }
    </style>
</head>

<body>
    <div
        id="main-wrapper"
        data-layout="vertical"
        data-navbarbg="skin5"
        data-sidebartype="full"
        data-sidebar-position="absolute"
        data-header-position="absolute"
        data-boxed-layout="full">
        <?php
        include_once(DATA . "navbar.php");
        include_once(DATA . "sidebar.php");
        ?>
        <div class="page-wrapper">
            <div class="container-fluid">
                <?php
                if ($_GET && !empty($_GET["page"])) {
                    $sayfa = $_GET["page"] . ".php";
                    if (file_exists((SAYFA . $sayfa))) {
                        include_once(SAYFA . $sayfa);
                    } else {
                        include_once(SAYFA . "home.php");
                    }
                } else {
                    include_once(SAYFA . "home.php");
                }
                ?>
            </div>
            <?php
            include_once(DATA . "footer.php");
            ?>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="./assets/libs/jquery/dist/jquery.min.js"></script>
    <script src="./dist/js/jquery.ui.touch-punch-improved.js"></script>
    <script src="./dist/js/jquery-ui.min.js"></script>
    <script src="./assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="./assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="./assets/extra-libs/sparkline/sparkline.js"></script>
    <script src="./dist/js/waves.js"></script>
    <script src="./dist/js/sidebarmenu.js"></script>
    <script src="./dist/js/custom.min.js"></script>
    <script src="./assets/libs/moment/min/moment.min.js"></script>
    <script src="./assets/extra-libs/multicheck/datatable-checkbox-init.js"></script>
    <script src="./assets/extra-libs/multicheck/jquery.multicheck.js"></script>
    <script src="./assets/extra-libs/DataTables/datatables.min.js"></script>

</body>

</html>