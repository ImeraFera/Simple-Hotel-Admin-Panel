<?php

@define("URL2", "include/DB/");
include_once("DB/personel_listele.php");
?>

<h2>Personeller</h2>
<hr>

<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Personel Ekle</h5>
                <hr>
                <form id="personelEkle" method="post">
                    <div class="mb-3">
                        <label class="form-label">Personel Adı Soyadı:</label>
                        <input type="text" class="form-control" id="personel_adSoyad" name="personel_adSoyad">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Personel Şifre:</label>
                        <input type="password" class="form-control" id="personel_sifre" name="personel_sifre">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Personel TC:</label>
                        <input type="text" maxlength="11" class="form-control" id="personel_tc" name="personel_tc">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Personel Telefon:</label>
                        <input type="tel" maxlength="10" class="form-control" id="personel_tel" name="personel_tel">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Personel Pozisyon:</label>
                        <input type="text" class="form-control" id="personel_pozisyon" name="personel_pozisyon">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Personel Maaş:</label>
                        <input type="number" class="form-control" id="personel_maas" name="personel_maas">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Personel Cinsiyet:</label>
                        <select class="form-select" id="personel_cinsiyet">
                            <option selected>Cinsiyet Seçiniz</option>
                            <option value="erkek">Erkek</option>
                            <option value="kadın">Kadın</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Personel Giris Tarihi:</label>
                        <input type="date" class="form-control" id="personel_girisTarihi" name="personel_girisTarihi">
                    </div>
                    <button type="submit" class="btn btn-primary">Personel Ekle</button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Personel Sil</h5>
                <hr>
                <form id="personelSil" method="post">
                    <div class="mb-3">
                        <label class="form-label">Personel Ad Soyad:</label>
                        <select class="form-select">
                            <option selected>Personel Seçiniz</option>
                            <?php foreach ($personeller as $personel): ?>
                            <option value="<?php echo $personel['personel_id']; ?>">
                                <?php echo $personel['personel_adSoyad']; ?>
                            </option>
                            <?php endforeach; ?>
                        </select>

                    </div>
                    <button type="submit" class="btn btn-primary">Personel Sil</button>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="scrollable-table">
            <table id="personelTable" class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Ad Soyad</th>
                        <th>Cinsiyet</th>
                        <th>TC</th>
                        <th>Telefon</th>
                        <th>Pozisyon</th>
                        <th>Maaş</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (isset($personeller) && is_array($personeller)) {
                        foreach ($personeller as $personel) {
                            echo "<tr>";
                            echo "<td>" . $personel['personel_id'] . "</td>";
                            echo "<td>" . $personel['personel_adSoyad'] . "</td>";
                            echo "<td>" . $personel['personel_cinsiyet'] . "</td>";
                            echo "<td>" . $personel['personel_tc'] . "</td>";
                            echo "<td>" . $personel['personel_tel'] . "</td>";
                            echo "<td>" . $personel['personel_pozisyon'] . "</td>";
                            echo "<td>" . $personel['personel_maas'] . "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='7'>Veri bulunamadı.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
$("#personelSil").submit(function(event) {
    event.preventDefault();

    var selectedPersonelId = $("#personelSil select").val();

    if (!selectedPersonelId || selectedPersonelId === "") {
        alert("Lütfen silmek istediğiniz personeli seçiniz.");
        return;
    }

    $.ajax({
        type: "POST",
        url: "<?= URL2 . "personel_sil.php" ?>",
        data: {
            personel_id: selectedPersonelId
        },
        dataType: "json",
        success: function(data) {
            alert(data.message);
            window.location.href = "?page=personeller";
        },
        error: function(xhr, status, error) {
            console.error("AJAX Hata: ", error);
        }
    });
});
</script>

<script>
document.addEventListener("DOMContentLoaded", function() {
    var personelGirisTarihiInput = document.getElementById("personel_girisTarihi");
    var bugununTarihi = new Date().toISOString().split('T')[0];
    personelGirisTarihiInput.addEventListener("input", function() {
        var secilenTarih = personelGirisTarihiInput.value;
        var secilenDate = new Date(secilenTarih);
        if (secilenDate < new Date(bugununTarihi)) {
            alert("Geçerli bir tarih seçiniz.");
            personelGirisTarihiInput.value = "";
        }
    });
});
$("#personelEkle").submit(function(event) {
    event.preventDefault();

    var formData = {
        personel_adSoyad: $("#personel_adSoyad").val(),
        personel_sifre: $("#personel_sifre").val(),
        personel_tc: $("#personel_tc").val(),
        personel_tel: $("#personel_tel").val(),
        personel_pozisyon: $("#personel_pozisyon").val(),
        personel_maas: $("#personel_maas").val(),
        personel_cinsiyet: $("#personel_cinsiyet option:selected").val(),
        personel_girisTarihi: $("#personel_girisTarihi").val()
    };

    if (formData.personel_cinsiyet === "Cinsiyet Seçiniz") {
        alert("Cinsiyet Seçiniz!");
        return;
    }
    $.ajax({
        type: "POST",
        url: "<?= URL2 . "personel_ekle.php" ?>",
        data: formData,
        dataType: "json",
        success: function(data) {
            alert(data.message);
            window.location.href = "?page=personeller";
        },
        error: function(xhr, status, error) {
            console.error("AJAX Hata: ", error);
        }
    });
});
</script>