<?php

@define("URL2", "include/DB/");
include_once("DB/rez_listele.php");
include_once("DB/musteri_listele.php");
include_once("DB/oda_listele.php");
include_once("DB/personel_listele.php");
include_once("DB/odemeTipi_listele.php");

?>

<h2>Rezervasyonlar</h2>
<hr>

<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Rezervasyon Ekle</h5>
                <hr>
                <form id="rezEkle" method="post">
                    <div class="mb-3">
                        <label class="form-label">Müşteri Seç:</label>
                        <select class="form-select" id="rez_musteriId" name="rez_musteriId">
                            <option value="">Müşteri Seçiniz</option>
                            <?php
                            if (isset($musteriler) && is_array($musteriler)) {
                                foreach ($musteriler as $musteri) {
                                    echo "<option value='" . $musteri['musteri_id'] . "'>" . $musteri['musteri_adSoyad'] . "</option>";
                                }
                            } else {
                                echo "<option disabled>Veri bulunamadı</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Oda Seç:</label>
                        <select class="form-select" id="rez_odaNo" name="rez_odaNo">
                            <option value="">Oda Seçiniz</option>
                            <?php
                            if (isset($odalar) && is_array($odalar)) {
                                foreach ($odalar as $oda) {
                                    echo "<option value='" . $oda['oda_no'] . "'>" . $oda['oda_no'] . " " . $oda['oda_durumu'] . "</option>";
                                }
                            } else {
                                echo "<option disabled>Veri bulunamadı</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Personel Seç:</label>
                        <select class="form-select" id="rez_ilgiliPersonel" name="rez_ilgiliPersonel">
                            <option value="">Personel Seçiniz</option>
                            <?php
                            if (isset($personeller) && is_array($personeller)) {
                                foreach ($personeller as $personel) {
                                    echo "<option value='" . $personel['personel_id'] . "'>" . $personel['personel_adSoyad'] . "</option>";
                                }
                            } else {
                                echo "<option disabled>Veri bulunamadı</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Rezervasyon Tarihi Seç:</label>
                        <input type="date" id="rez_tarih" name="rez_tarih" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Rezervasyon Bitiş Tarihi Seç:</label>
                        <input type="date" id="rez_bitisTarihi" name="rez_bitisTarihi" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Ödeme Tipi Seç:</label>
                        <select class="form-select" id="rez_odemeTipi" name="rez_odemeTipi">
                            <option value="">Ödeme Tipi Seçiniz</option>
                            <?php
                            if (isset($odemeTipleri) && is_array($odemeTipleri)) {
                                foreach ($odemeTipleri as $odemeTipi) {
                                    echo "<option value='" . $odemeTipi['odemeTip_id'] . "'>" . $odemeTipi['odemeTip_ad'] . "</option>";
                                }
                            } else {
                                echo "<option disabled>Veri bulunamadı</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary">Rezervasyon Ekle</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Rezervasyon Sil</h5>
                <hr>
                <form id="rezSil" method="post">
                    <div class="mb-3">
                        <label class="form-label">Müşteri No:</label>
                        <?php
                        if (isset($rezler)) {
                            echo '<select class="form-select">';
                            echo '<option selected>Müşteri Seçiniz</option>';

                            foreach ($rezler as $rez) {

                                $musteriId = $rez['rez_musteriId'];
                                $musteriSorgusu = $baglanti->prepare("call getMusteri(:musteri_id)");
                                $musteriSorgusu->bindParam(':musteri_id', $musteriId, PDO::PARAM_INT);
                                $musteriSorgusu->execute();
                                $musteri = $musteriSorgusu->fetch(PDO::FETCH_ASSOC);
                                if ($musteri) {
                                    echo '<option value="' . $rez['rez_id'] . "_" . $rez['rez_odaNo'] . '"> Müşteri: ' . $musteri['musteri_adSoyad'] . '</option>';
                                } else {
                                    echo '<option value="' . $rez['rez_id'] . '"> Müşteri Bulunamadı</option>';
                                }
                            }

                            echo '</select>';
                        } else {
                            echo '<p>Hata: Müşteri bilgileri alınamadı.</p>';
                        }
                        ?>

                    </div>
                    <button type="submit" class="btn btn-primary">Kayıt Sil</button>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="scrollable-table">
            <table id="personelTable" class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Rez No</th>
                        <th>Oda No</th>
                        <th>Müşteri No</th>
                        <th>Ad Soyad</th>
                        <th>Başlangıç Tarihi</th>
                        <th>Bitiş Tarihi</th>
                        <th>Ödeme Tipi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    foreach ($rezler as $index => $rez) {

                        $musteriId = $rez['rez_musteriId'];
                        $musteriSorgusu = $baglanti->prepare("call getMusteri(:musteri_id)");
                        $musteriSorgusu->bindParam(':musteri_id', $musteriId, PDO::PARAM_INT);
                        $musteriSorgusu->execute();
                        $musteri = $musteriSorgusu->fetch(PDO::FETCH_ASSOC);

                        echo "<tr>";
                        echo "<td>" . $rez['rez_id'] . "</td>";
                        echo "<td>" . $rez['rez_odaNo'] . "</td>";
                        echo "<td>" . $rez['rez_musteriId'] . "</td>";
                        echo "<td>" . $musteri['musteri_adSoyad'] . "</td>";
                        echo "<td>" . $rez['rez_tarih'] . "</td>";
                        echo "<td>" . $rez['rez_bitisTarihi'] . "</td>";
                        echo "<td>" . $rez['rez_odemeTipi'] . "</td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
document.addEventListener("DOMContentLoaded", function() {
    var today = new Date().toISOString().split("T")[0];

    document.getElementById("rez_tarih").setAttribute("min", today);

    document.getElementById("rez_tarih").addEventListener("change", function() {
        var selectedDate = document.getElementById("rez_tarih").value;

        var nextDay = new Date(selectedDate);
        nextDay.setDate(nextDay.getDate() + 1);

        document.getElementById("rez_bitisTarihi").setAttribute("min", nextDay.toISOString().split("T")[
            0]);
    });
});
</script>
<script>
$(document).ready(function() {
    $("#rezSil").submit(function(event) {
        event.preventDefault();

        var selectedValue = $("#rezSil select").val();
        var values = selectedValue.split('_');
        var rezId = values[0];
        var odaNo = values[1];
        var formData = {
            rez_id: rezId,
            rez_odaNo: odaNo
        };
        $.ajax({
            type: "POST",
            url: "<?= URL2 . "rez_sil.php" ?>",
            data: formData,
            dataType: "json",
            success: function(data) {
                alert(data.message);
                location.reload();
            },
            error: function(xhr, status, error) {
                console.error("AJAX Hata: ", error);
            }
        });
    });
});
</script>
<script>
$(document).ready(function() {
    $("#rezEkle").submit(function(event) {
        event.preventDefault();

        var formData = {
            rez_musteriId: $("#rez_musteriId").val(),
            rez_odaNo: $("#rez_odaNo").val(),
            rez_ilgiliPersonel: $("#rez_ilgiliPersonel").val(),
            rez_tarih: $("#rez_tarih").val(),
            rez_bitisTarihi: $("#rez_bitisTarihi").val(),
            rez_odemeTipi: $("#rez_odemeTipi").val()
        };

        $.ajax({
            type: "POST",
            url: "<?= URL2 . "rez_ekle.php" ?>",
            data: formData,
            dataType: "json",
            success: function(data) {
                alert(data.message);
                location.reload();

            },
            error: function(xhr, status, error) {
                console.error("AJAX Hata: ", error);
            }
        });
    });
});
</script>