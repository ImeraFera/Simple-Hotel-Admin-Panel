<?php
@session_start();

// if (!isset($_SESSION["admin_id"])) {
//     echo "Oturum açmamış bir kullanıcının erişim izni yok.";
//     exit;
// }

@define("URL2", "include/DB/");

?>

<h2>Modül Ekle</h2>
<hr>

<div id="notification" class="position-fixed top-0 end-0 p-3" style="z-index: 1050; width: 300px; margin-top: 60px">
</div>
<div class="col-6">
    <div class="card">
        <form class="form-horizontal" method = "post">
            <div class="card-body">
                <h4 class="card-title" _msttexthash="309257" _msthash="58">Modül Bilgileri</h4>
                <div class="form-group row">
                    <label for="fname" class="col-sm-3 text-end control-label col-form-label" _msttexthash="16315"
                        _msthash="59">Modül Adı</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" id="modulAd" _mstplaceholder="219180" _msthash="60">
                    </div>
                </div>
                
                <div class="form-group row">
                    <label for="fname" class="col-sm-3 text-end control-label col-form-label" _msttexthash="16315"
                        _msthash="59">Modül Url</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" id="modulUrl" _mstplaceholder="219180" _msthash="60">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="fname" class="col-sm-3 text-end control-label col-form-label" _msttexthash="16315"
                        _msthash="59">Modül Icon</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" id="modulIcon" _mstplaceholder="219180" _msthash="60">
                    </div>
                </div>
            </div>
            <div class="border-top">
                <div class="card-body">
                    <button type="button" class="btn btn-primary" id="modulEkleBtn"  _msttexthash="90142" _msthash="70"> Ekle </button>
                </div>
            </div>
        </form>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
$(document).ready(function () {
    $("#modulEkleBtn").click(function () {
        var modulAd = $("#modulAd").val();
        var modulUrl = $("#modulUrl").val();
        var modulIcon = $("#modulIcon").val();
        var data = {
            modulAd: modulAd,
            modulUrl: modulUrl,
            modulIcon: modulIcon
        };
        $.ajax({
            type: "POST",
            url: "<?=URL2."modul_ekle.php"?>",
            data: data,
            success: function (response) {
                    location.reload();
            }
        });
    });
});
</script>
