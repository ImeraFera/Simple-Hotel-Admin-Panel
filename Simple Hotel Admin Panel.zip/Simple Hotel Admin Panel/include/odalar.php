<?php

@define("URL2", "include/DB/");
include_once("DB/oda_listele.php");

?>

<h2>Odalar</h2>
<hr>

<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Oda Ekle</h5>
                <hr>
                <form id="odaEkle" method="post">
                    <div class="mb-3">
                        <label class="form-label">Oda Tipi:</label>
                        <select class="form-select" id="oda_tipi" name="oda_tipi">
                            <option value="1 Kişilik" selected>1 Kişilik</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Oda Fiyatı:</label>
                        <input type="text" class="form-control" id="oda_fiyat" name="oda_fiyat">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Oda Durumu:</label>
                        <select class="form-select" id="oda_durumu" nname="oda_durumu">
                            <option value="Boş" selected>Boş</option>
                            <option value="Dolu">Dolu</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Oda Ekle</button>
                </form>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Oda Sil</h5>
                <hr>
                <form id="odaSil" method="post">
                    <div class="mb-3">
                        <label class="form-label">Oda:</label>
                        <?php

                        if (isset($odalar)) {
                            echo '<select class="form-select">';
                            echo '<option selected>Oda Seçiniz</option>';
                            foreach ($odalar as $oda) {
                                echo '<option value="' . $oda['oda_no'] . '"> ODA: ' . $oda['oda_no'] . '</option>';
                            }
                            echo '</select>';
                        } else {
                            echo '<p>Hata: Oda bilgileri alınamadı.</p>';
                        }
                        ?>
                    </div>
                    <button type="submit" class="btn btn-primary">Oda Sil</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Oda Güncelle</h5>
                <hr>
                <form id="odaGuncelle" method="post">
                    <div class="mb-3">
                        <label class="form-label">Oda:</label>
                        <?php

                        if (isset($odalar)) {
                            echo '<select class="form-select" id="oda_no" name=" "oda_no"">';
                            echo '<option selected>Oda Seçiniz</option>';
                            foreach ($odalar as $oda) {
                                echo '<option value="' . $oda['oda_no'] . '"> ODA: ' . $oda['oda_no'] . '</option>';
                            }
                            echo '</select>';
                        } else {
                            echo '<p>Hata: Oda bilgileri alınamadı.</p>';
                        }
                        ?>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Oda Tipi:</label>
                        <select class="form-select" id="oda_tipi" name="oda_tipi">
                            <option value="1 Kişilik" selected>1 Kişilik</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Oda Fiyatı:</label>
                        <input type="text" required class="form-control" id="oda_fiyatGuncel" name="oda_fiyatGuncel">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Oda Durumu:</label>
                        <select class="form-select" id="oda_durumu" nname="oda_durumu">
                            <option value="Boş" selected>Boş</option>
                            <option value="Dolu">Dolu</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Oda Güncelle</button>
                </form>
            </div>
        </div>
    </div>

</div>
<div class="row">
    <div class="col-md-12">
        <div class="scrollable-table">
            <table id="personelTable" class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Oda No</th>
                        <th>Oda Tipi</th>
                        <th>Oda Durumu</th>
                        <th>Oda Fiyatı</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    foreach ($odalar as $index => $oda) {
                        echo "<tr>";
                        echo "<td>" . $oda['oda_no'] . "</td>";
                        echo "<td>" . $oda['oda_tipi'] . "</td>";
                        echo "<td>" . $oda['oda_durumu'] . "</td>";
                        echo "<td>" . $oda['oda_fiyat'] . "</td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
$(document).ready(function() {
    $("#odaGuncelle").submit(function(event) {
        event.preventDefault();

        var formData = {
            oda_no: $("#oda_no").val(),
            oda_fiyat: $("#oda_fiyatGuncel").val(),
            oda_durumu: $("#oda_durumu").val()
        };

        if (formData.oda_no == "Oda Seçiniz") {
            return;
        }

        $.ajax({
            type: "POST",
            url: "<?= URL2 . "oda_guncelle.php" ?>",
            data: formData,
            dataType: "json",
            success: function(data) {
                alert("Oda Güncelleme Başarılı!");
                window.location.reload();
            },
            error: function(xhr, status, error) {
                console.error("AJAX Hata: ", error);
            }
        });
    });
});

</script>

<script>
$(document).ready(function() {
    $("#odaSil").submit(function(event) {
        event.preventDefault();
        var selectedOda = $("#odaSil select").val();
        var formData = {
            oda_no: selectedOda
        };

        $.ajax({
            type: "POST",
            url: "<?= URL2 . "oda_sil.php" ?>",
            data: formData,
            dataType: "json",
            success: function(data) {
                alert(data.message);
                window.location.reload();
            },
            error: function(xhr, status, error) {
                console.error("AJAX Hata: ", error);
            }
        });
    });
});
</script>
<script>
$(document).ready(function() {
    $("#odaEkle").submit(function(event) {
        event.preventDefault();

        var formData = {
            oda_tipi: $("#oda_tipi").val(),
            oda_fiyat: $("#oda_fiyat").val(),
            oda_durumu: $("#oda_durumu").val()
        };

        $.ajax({
            type: "POST",
            url: "<?= URL2 . "oda_ekle.php" ?>",
            data: formData,
            dataType: "json",
            success: function(data) {
                alert("Oda Kaydetme Başarılı!");
                window.location.reload();
            },
            error: function(xhr, status, error) {
                console.error("AJAX Hata: ", error);
            }
        });
    });
});
</script>