<?php

@define("URL2", "include/DB/");
include_once("DB/musteri_listele.php");
?>

<h2>Müşteriler</h2>
<hr>

<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Müşteri Ekle</h5>
                <hr>
                <form id="musteriEkle" method="post">
                    <div class="mb-3">
                        <label class="form-label">Müşteri Adı Soyadı:</label>
                        <input type="text" class="form-control" id="musteri_adSoyad" name="musteri_adSoyad">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Müşteri Cinsiyet:</label>
                        <select class="form-select" id="musteri_cinsiyet">
                            <option selected>Cinsiyet Seçiniz</option>
                            <option value="Erkek">Erkek</option>
                            <option value="Kadın">Kadın</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Müşteri TC:</label>
                        <input type="text" maxlength="11" class="form-control" id="musteri_tc" name="musteri_tc">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Müşteri Telefon:</label>
                        <input type="tel" maxlength="10" class="form-control" id="musteri_tel" name="musteri_tel">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Müşteri Doğum Tarihi:</label>
                        <input type="date" class="form-control" id="musteri_dogumTarihi" name="musteri_dogumTarihi">
                    </div>
                    <button type="submit" class="btn btn-primary">Müşteri Ekle</button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Müşteri Sil</h5>
                <hr>
                <form id="musteriSil" method="post">
                    <div class="mb-3">
                        <label class="form-label">Müşteri Ad Soyad:</label>
                        <select class="form-select" name="musteri_id" id="musteri_id">
                            <option value="" selected>Müşteri Seçiniz</option>
                            <?php
                            if (isset($musteriler) && is_array($musteriler)) {
                                foreach ($musteriler as $musteri) {
                                    echo "<option value='" . $musteri['musteri_id'] . "'>" . $musteri['musteri_adSoyad'] . "</option>";
                                }
                            } else {
                                echo "<option disabled>Veri bulunamadı</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Müşteri Sil</button>
                </form>

            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="scrollable-table">
            <table id="musteriTable" class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Ad Soyad</th>
                        <th>Cinsiyet</th>
                        <th>TC</th>
                        <th>Telefon</th>
                        <th>Dogum Tarihi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (isset($musteriler) && is_array($musteriler)) {
                        foreach ($musteriler as $musteri) {
                            echo "<tr>";
                            echo "<td>" . $musteri['musteri_id'] . "</td>";
                            echo "<td>" . $musteri['musteri_adSoyad'] . "</td>";
                            echo "<td>" . $musteri['musteri_cinsiyet'] . "</td>";
                            echo "<td>" . $musteri['musteri_tc'] . "</td>";
                            echo "<td>" . $musteri['musteri_tel'] . "</td>";
                            echo "<td>" . $musteri['musteri_dogumTarihi'] . "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5'>Veri bulunamadı</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
$("#musteriSil").submit(function(event) {
    event.preventDefault();

    var selectedPersonelId = $("#musteriSil select").val();

    $.ajax({
        type: "POST",
        url: "<?= URL2 . "musteri_sil.php" ?>",
        data: {
            musteri_id: selectedPersonelId
        },
        dataType: "json",
        success: function(data) {
            alert(data.message);
            window.location.href = "?page=musteriler";
        },
        error: function(xhr, status, error) {
            console.error("AJAX Hata: ", error);
        }
    });
});
</script>


<script>

$("#musteriEkle").submit(function(event) {
    event.preventDefault();

    var formData = {
        musteri_adSoyad: $("#musteri_adSoyad").val(),
        musteri_sifre: $("#musteri_sifre").val(),
        musteri_tc: $("#musteri_tc").val(),
        musteri_tel: $("#musteri_tel").val(),
        musteri_pozisyon: $("#musteri_pozisyon").val(),
        musteri_maas: $("#musteri_maas").val(),
        musteri_cinsiyet: $("#musteri_cinsiyet option:selected").val(),
        musteri_dogumTarihi: $("#musteri_dogumTarihi").val()
    };

    if (formData.musteri_cinsiyet === "Cinsiyet Seçiniz") {
        alert("Cinsiyet Seçiniz!");
        return;
    }

    $.ajax({
        type: "POST",
        url: "<?= URL2 . "musteri_ekle.php" ?>",
        data: formData,
        dataType: "json",
        success: function(data) {
            alert(data.message);
            window.location.href = "?page=musteriler";
        },
        error: function(xhr, status, error) {
            console.error("AJAX Hata: ", error);
        }
    });
});
</script>