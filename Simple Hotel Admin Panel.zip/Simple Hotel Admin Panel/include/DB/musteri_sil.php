<?php

@define("DATA", "../../data/");
include_once(DATA . "baglanti.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $musteri_id = $_POST["musteri_id"];

    $sql = "call musteriSil(:musteriId)";
    $stmt = $baglanti->prepare($sql);
    $stmt->bindParam(':musteriId', $musteri_id);
    $stmt->execute();

    echo json_encode(["success" => true, "message" => "Müşteri Silme Başarılı!"]);
} else {
    echo "Geçersiz istek";
}

?>