<?php

@define("DATA", "../../data/");
include_once(DATA . "baglanti.php");
$rezId = $_POST['rez_id'];
$odaId = $_POST['rez_odaNo'];

try {
    
    $sql = "call rezSil(:rezId,:rezOdaNo)";
    $stmt = $baglanti->prepare($sql);
    $stmt->bindParam(':rezId', $rezId);
    $stmt->bindParam(':rezOdaNo', $odaId);
    $stmt->execute();

    echo json_encode(["success" => true, "message" => "Rezervasyon başarıyla silindi"]);

} catch (PDOException $e) {
    echo json_encode(["success" => false, "message" => "Hata: Rezervasyon silinirken bir sorun oluştu " . $e->getMessage()]);
}

?>
