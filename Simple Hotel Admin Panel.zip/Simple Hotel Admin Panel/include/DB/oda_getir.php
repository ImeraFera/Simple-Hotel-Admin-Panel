<?php

@define("DATA", "../../data/");
include_once(DATA . "baglanti.php");

function odaGetir($odaId){
    global $baglanti;
    try {
        $stmt = $baglanti->prepare("CALL getOda(:odaId)");
        $stmt->bindParam(':odaId', $odaId, PDO::PARAM_INT);
        $stmt->execute();
        
        $oda = $stmt->fetch(PDO::FETCH_ASSOC);
        return $oda;
    } catch (PDOException $e) {
        echo "Hata: " . $e->getMessage();
    }
}
?>
