<?php

@define("DATA", "../../data/");
include_once(DATA . "baglanti.php");

try {
    $sql = "call rezListele()";
    $stmt = $baglanti->query($sql);
    $rezler = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    echo json_encode(["success" => false, "message" => "Hata: " . $e->getMessage()]);
}
?>
