<?php

@define("DATA", "../../data/");
include_once(DATA . "baglanti.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $modulAd = $_POST["modulAd"];
    $modulUrl = $_POST["modulUrl"];
    $modulIcon = $_POST["modulIcon"];

    $sql = "CALL modulEkle(:modulAd, :modulUrl, :modulIcon)";

    $stmt = $baglanti->prepare($sql);
    $stmt->bindParam(':modulAd', $modulAd);
    $stmt->bindParam(':modulUrl', $modulUrl);
    $stmt->bindParam(':modulIcon', $modulIcon);

    $stmt->execute();

    echo "Modul added successfully"; 
}

?>
