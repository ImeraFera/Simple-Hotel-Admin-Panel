<?php

@define("DATA", "../../data/");
include_once(DATA . "baglanti.php");

try {
    $stmt = $baglanti->query("CALL rezBitisTarihiEsitMusteriListele()");
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    echo json_encode(["success" => false, "message" => "Hata: " . $e->getMessage()]);
}
?>
