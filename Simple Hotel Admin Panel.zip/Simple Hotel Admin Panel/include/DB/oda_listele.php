<?php

@define("DATA", "../../data/");
include_once(DATA . "baglanti.php");

try {
    $stmt = $baglanti->query("call odaListele()");
    $odalar = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
}
?>
