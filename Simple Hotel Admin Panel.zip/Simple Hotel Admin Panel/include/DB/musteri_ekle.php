<?php

@define("DATA", "../../data/");
include_once(DATA . "baglanti.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $musteri_adSoyad = $_POST["musteri_adSoyad"];
    $musteri_cinsiyet = $_POST["musteri_cinsiyet"];
    $musteri_dogumTarihi = $_POST["musteri_dogumTarihi"];
    $musteri_tc = $_POST["musteri_tc"];
    $musteri_tel = $_POST["musteri_tel"];

    $sql = "CALL musteriEkle(:musteri_adSoyad, :musteri_cinsiyet, :musteri_dogumTarihi, :musteri_tc, :musteri_tel)";
    $stmt = $baglanti->prepare($sql);
    $stmt->bindParam(':musteri_adSoyad', $musteri_adSoyad);
    $stmt->bindParam(':musteri_cinsiyet', $musteri_cinsiyet);
    $stmt->bindParam(':musteri_dogumTarihi', $musteri_dogumTarihi);
    $stmt->bindParam(':musteri_tc', $musteri_tc);
    $stmt->bindParam(':musteri_tel', $musteri_tel);
    $stmt->execute();

    echo json_encode(["success" => true, "message" => "Müşteri Ekleme Başarılı!"]);
} else {
    echo "Geçersiz istek";
}

?>
