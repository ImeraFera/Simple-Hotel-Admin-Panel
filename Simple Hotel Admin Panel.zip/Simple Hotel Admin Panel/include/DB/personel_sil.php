<?php

@define("DATA", "../../data/");
include_once(DATA . "baglanti.php");

try {
    $personelId = $_POST['personel_id'];
    $sql = "call personelSil(:personelId)";
    $stmt = $baglanti->prepare($sql);
    $stmt->bindParam(':personelId', $personelId);
    $stmt->execute();
    echo json_encode(["success" => true, "message" => "Personel başarıyla silindi"]);
} catch (PDOException $e) {
    echo json_encode(["success" => false, "message" => "Hata: " . $e->getMessage()]);
}

?>