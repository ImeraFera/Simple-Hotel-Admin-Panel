<?php

@define("DATA", "../../data/");
include_once(DATA . "baglanti.php");

$modulID = $_POST['modul_id'];

$sql = "call modulSil(:modul_id)";
$stmt = $baglanti->prepare($sql);
$stmt->bindParam(':modul_id', $modulID, PDO::PARAM_INT);

$stmt->execute();

echo "Modül başarıyla silindi!";

$baglanti = null;
?>

?>