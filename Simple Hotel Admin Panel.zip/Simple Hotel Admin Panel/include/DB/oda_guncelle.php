<?php

@define("DATA", "../../data/");
include_once(DATA . "baglanti.php");

$oda_no = $_POST['oda_no'];
$oda_fiyat = $_POST['oda_fiyat'];
$oda_durumu = $_POST['oda_durumu'];

try {

    $stmt = $baglanti->prepare("CALL odaGuncelle(:odaNo, :odaFiyat, :odaDurumu)");
    $stmt->bindParam(':odaNo', $oda_no, PDO::PARAM_INT);
    $stmt->bindParam(':odaFiyat', $oda_fiyat, PDO::PARAM_INT);
    $stmt->bindParam(':odaDurumu', $oda_durumu, PDO::PARAM_STR);
    $stmt->execute();

    echo json_encode(["success" => true, "message" => "Oda başarıyla guncellendi!"]);

} catch (PDOException $e) {
    echo json_encode(["success" => false, "message" => "Hata: Oda güncellenirken bir sorun oluştu "]);
}

?>