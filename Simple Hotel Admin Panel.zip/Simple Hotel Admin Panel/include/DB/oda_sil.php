<?php

@define("DATA", "../../data/");
include_once(DATA . "baglanti.php");
$oda_no = $_POST['oda_no'];

try {
    
    $sql = "call odaSil(:odaNo)";
    $stmt = $baglanti->prepare($sql);
    $stmt->bindParam(':odaNo', $oda_no);
    $stmt->execute();

    echo json_encode(["success" => true, "message" => "Oda başarıyla silindi"]);

} catch (PDOException $e) {
    echo json_encode(["success" => false, "message" =>  $e->getMessage()]);
}

?>
