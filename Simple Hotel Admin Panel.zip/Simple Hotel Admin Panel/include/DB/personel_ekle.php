<?php

@define("DATA", "../../data/");
include_once(DATA . "baglanti.php");

$adSoyad = $_POST['personel_adSoyad'];
$sifre = $_POST['personel_sifre'];
$tc = $_POST['personel_tc'];
$tel = $_POST['personel_tel'];
$pozisyon = $_POST['personel_pozisyon'];
$maas = $_POST['personel_maas'];
$cinsiyet = $_POST['personel_cinsiyet'];
$girisTarihi = $_POST['personel_girisTarihi'];

try {
    $hashSifre = password_hash($sifre, PASSWORD_DEFAULT);

    $sql = "call personelEkle(:adSoyad,:sifre,:cinsiyet,:tc,:tel,:pozisyon,:maas,:girisTarihi)";
    $stmt = $baglanti->prepare($sql);
    $stmt->bindParam(':adSoyad', $adSoyad);
    $stmt->bindParam(':sifre', $hashSifre);
    $stmt->bindParam(':tc', $tc);
    $stmt->bindParam(':tel', $tel);
    $stmt->bindParam(':pozisyon', $pozisyon);
    $stmt->bindParam(':maas', $maas);
    $stmt->bindParam(':cinsiyet', $cinsiyet);
    $stmt->bindParam(':girisTarihi', $girisTarihi);

    $stmt->execute();

    echo json_encode(["success" => true, "message" => "Personel başarıyla eklendi"]);

} catch (PDOException $e) {
    echo json_encode(["success" => false, "message" => "Hata: Eklemek istediğiniz personelin bilgileri zaten kayıtlı olabilir. Tekrar Deneyiniz!"]);
}
?>