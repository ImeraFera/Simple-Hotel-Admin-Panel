<?php

use function PHPSTORM_META\type;

@define("DATA", "../../data/");
include_once(DATA . "baglanti.php");
include_once("./oda_getir.php");

try {

    $rez_musteriId = $_POST['rez_musteriId'];
    $rez_odaNo = $_POST['rez_odaNo'];
    $rez_ilgiliPersonel = $_POST['rez_ilgiliPersonel'];
    $rez_tarih = $_POST['rez_tarih'];
    $rez_bitisTarihi = $_POST['rez_bitisTarihi'];
    $rez_odemeTipi = $_POST['rez_odemeTipi'];

    $sql = "call rezEkle(:rez_odaNo, :rez_musteriId, :rez_ilgiliPersonel, :rez_tarih, :rez_bitisTarihi, :rez_odemeTipi)";
    $statement = $baglanti->prepare($sql);
    $statement->bindParam(':rez_musteriId', $rez_musteriId, PDO::PARAM_INT);
    $statement->bindParam(':rez_odaNo', $rez_odaNo, PDO::PARAM_INT);
    $statement->bindParam(':rez_ilgiliPersonel', $rez_ilgiliPersonel, PDO::PARAM_INT);
    $statement->bindParam(':rez_tarih', $rez_tarih, PDO::PARAM_STR);
    $statement->bindParam(':rez_bitisTarihi', $rez_bitisTarihi, PDO::PARAM_STR);
    $statement->bindParam(':rez_odemeTipi', $rez_odemeTipi, PDO::PARAM_INT);
    $statement->execute();

    // $oda = odaGetir($rez_odaNo);
    // $oda_fiyat =$oda['oda_fiyat'];

    // $sql2 = "CALL odemeEkle(:musteriId, :odemeTutari, :odemeTipi, :odemeTarihi)";
    // $statement2 = $baglanti->prepare($sql2); 
    // $statement2->bindParam(':musteriId', $rez_musteriId, PDO::PARAM_INT);
    // $statement2->bindParam(':odemeTutari', $oda_fiyat, PDO::PARAM_INT); 
    // $statement2->bindParam(':odemeTipi', $rez_odemeTipi, PDO::PARAM_INT);
    // $statement2->bindParam(':odemeTarihi', $rez_tarih, PDO::PARAM_STR);

    // $statement2->execute();

    echo json_encode(["success" => true, "message" => "Rezervasyon başarıyla eklendi"]);

} catch (PDOException $e) {
    echo json_encode(["success" => false, "message" => "Hata: Rezervasyon eklenirken bir sorun oluştu " . $e->getMessage()]);
}

?>