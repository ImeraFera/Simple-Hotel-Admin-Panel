<?php

@define("DATA", "../../data/");
include_once(DATA . "baglanti.php");

try {
    $stmt = $baglanti->query("call odemeListele()");
    $odemeler = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    echo json_encode(["success" => false, "message" => "Hata: " . $e->getMessage()]);
}
?>