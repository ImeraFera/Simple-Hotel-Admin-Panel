<?php

@session_start();

// if (!isset($_SESSION["admin_id"])) {
//     // Kullanıcı oturum açmamışsa, işlemi reddet
//     echo "Oturum açmamış bir kullanıcının erişim izni yok.";
//     exit;
// }

@define("URL2", "include/DB/");

$sql = "SELECT modul_id, modul_ad FROM moduller";
$stmt = $baglanti->prepare($sql);
$stmt->execute();
?>

<h2>Modül Sil</h2>
<hr>

<div id="notification" class="position-fixed top-0 end-0 p-3" style="z-index: 1050; width: 300px; margin-top: 60px">
</div>

<div class="col-md-6">
    <div class="card">
        <form class="form-horizontal" method="POST">
            <div class="card-body">
                <div class="container mt-1">
                    <h6>Silinecek Modül ID</h6>
                    <select class="form-select" id="modulSelect" aria-label="Default select example" name="modul_id">
                        <option value="">Bir Modül Seçiniz.</option>
                        <?php
                        $sql = "SELECT modul_id, modul_ad FROM moduller";
                        $stmt = $baglanti->prepare($sql);
                        $stmt->execute();
                        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                            echo '<option value="' . $row["modul_id"] . '">' . $row["modul_ad"] . '</option>';
                        }
                        ?>
                    </select>

                </div>

                <div class="text-center mt-3">
                    <button type="button" class="btn btn-primary" id="gonder">Gönder</button>
                </div>

            </div>
        </form>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
$(document).ready(function() {
    $("#gonder").click(function() {
        var selectedModulID = $("#modulSelect").val(); 
        $.ajax({
            type: "POST",
            url: "<?= URL2 . "modul_sil.php" ?>",
            data: {
                modul_id: selectedModulID
            },
            success: function(response) {

                location.reload();
            },
            error: function() {
                console.error("AJAX Hata");
            }
        });
    });
});
</script>