<?php
@session_start();

// if (!isset($_SESSION["admin_id"])) {
//     echo "Oturum açmamış bir kullanıcının erişim izni yok.";
//     exit;
// }
@define("URL", "include/DB/");
include_once("DB/cikacakMusterileri_listele.php");


?>
<h2>Çıkması Gereken Müşteriler</h2>
<hr>


<div class="row">
    <div class="col-md-12">
        <div class="scrollable-table">
            <table id="personelTable" class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Rez No</th>
                        <th>Müşteri No</th>
                        <th>Müşteri Adı</th>
                        <th>Müşteri TC</th>
                        <th>Müşteri Tel</th>
                    </tr>
                </thead>
                <tbody>
                   
                </tbody>
            </table>
        </div>
    </div>
</div>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
