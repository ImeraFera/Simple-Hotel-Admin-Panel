<?php

@define("URL2", "include/DB/");
include_once("DB/rez_listele.php");
include_once("DB/musteri_listele.php");
include_once("DB/oda_listele.php");
include_once("DB/personel_listele.php");
include_once("DB/odemeTipi_listele.php");
include_once("DB/odeme_listele.php");

?>

<h2>Ödemeler</h2>
<hr>

<div class="row">
    <div class="col-md-12">
        <div class="scrollable-table">
            <table id="personelTable" class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Ödeme No</th>
                        <th>Müşteri No</th>
                        <th>Ödeme Tutarı</th>
                        <th>Ödeme Tipi</th>
                        <th>Ödeme Tarihi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    foreach ($odemeler as $index => $odeme) {

                        echo "<tr>";
                        echo "<td>" . $odeme['odeme_id'] . "</td>";
                        echo "<td>" . $odeme['musteri_id'] . "</td>";
                        echo "<td>" . $odeme['odeme_tutari'] . "</td>";
                        echo "<td>" . $odeme['odeme_tipi'] . "</td>";
                        echo "<td>" . $odeme['odeme_tarihi'] . "</td>";
                        echo "</tr>";

                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
document.addEventListener("DOMContentLoaded", function() {
    var today = new Date().toISOString().split("T")[0];

    document.getElementById("rez_tarih").setAttribute("min", today);

    document.getElementById("rez_tarih").addEventListener("change", function() {
        var selectedDate = document.getElementById("rez_tarih").value;

        var nextDay = new Date(selectedDate);
        nextDay.setDate(nextDay.getDate() + 1);

        document.getElementById("rez_bitisTarihi").setAttribute("min", nextDay.toISOString()
            .split("T")[
                0]);
    });
});
</script>
<script>
$(document).ready(function() {
    $("#odemeSil").submit(function(event) {
        event.preventDefault();

        var selectedValue = $("#rezSil select").val();
        var values = selectedValue.split('_');
        var rezId = values[0];
        var odaNo = values[1];
        var formData = {
            rez_id: rezId,
            rez_odaNo: odaNo
        };
        $.ajax({
            type: "POST",
            url: "<?= URL2 . "rez_sil.php" ?>",
            data: formData,
            dataType: "json",
            success: function(data) {
                alert(data.message);
                location.reload();
            },
            error: function(xhr, status, error) {
                console.error("AJAX Hata: ", error);
            }
        });
    });
});
</script>
<script>
$(document).ready(function() {
    $("#rezEkle").submit(function(event) {
        event.preventDefault();

        var formData = {
            rez_musteriId: $("#rez_musteriId").val(),
            rez_odaNo: $("#rez_odaNo").val(),
            rez_ilgiliPersonel: $("#rez_ilgiliPersonel").val(),
            rez_tarih: $("#rez_tarih").val(),
            rez_bitisTarihi: $("#rez_bitisTarihi").val(),
            rez_odemeTipi: $("#rez_odemeTipi").val()
        };

        $.ajax({
            type: "POST",
            url: "<?= URL2 . "rez_ekle.php" ?>",
            data: formData,
            dataType: "json",
            success: function(data) {
                alert(data.message);
                location.reload();

            },
            error: function(xhr, status, error) {
                console.error("AJAX Hata: ", error);
            }
        });
    });
});
</script>