<footer class="footer text-center">
    All Rights Reserved by myHotel.
</footer>