<?php
@session_start();
@ob_start();
include_once(DATA . "baglanti.php");

$query = "SELECT * FROM moduller";
$stmt = $baglanti->prepare($query);
$stmt->execute();

?>
<aside class="left-sidebar" data-sidebarbg="skin5">
    <!-- Sidebar scroll-->
    <div class="scroll-sidebar">
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav">
            <ul id="sidebarnav" class="pt-4">
                <?php
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    echo '<li class="sidebar-item">';

                    echo '<a class="sidebar-link waves-effect waves-dark sidebar-link" href="'
                        . $row["modul_url"] . '" aria-expanded="false"><i class="mdi '
                        . $row["modul_icon"] . '"></i><span class="hide-menu">'
                        . $row["modul_ad"] . '</span></a>';
                    echo '</li>';
                }
                ?>
            </ul>
        </nav>
    </div>
</aside>