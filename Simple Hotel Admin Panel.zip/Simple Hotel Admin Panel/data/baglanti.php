<?php
$host = "localhost"; 
$username = "root"; 
$password = ""; 
$database = "otel_veritabani"; 

try {
    $baglanti = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $baglanti->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch (PDOException $e) {
    die("PDO bağlantısı başarısız: " . $e->getMessage());
}
?>
